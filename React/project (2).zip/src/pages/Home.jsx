import Header from "../components/Header";
import Hero from "../components/Hero";
import SectionHeader from "../components/SectionHeader";
import ProductCard from "../components/ProductCard";
import Footer from "../components/Footer";
import "./Home.css";

export default function Home() {
  return (
    <div className="home">
      <Header />
      <Hero />

      <main className="container">
        {/* 오늘의 특가 */}
        <section className="home-section">
          <SectionHeader title="오늘의 특가" description="자정까지 한정 수량" />
          <div className="products">
            <ProductCard />
            <ProductCard />
            <ProductCard />
            <ProductCard />
          </div>
        </section>

        {/* 랭킹 */}
        <section className="home-section">
          <SectionHeader title="랭킹" description="가장 인기 있는 아이템" />
          <div className="products">
            <ProductCard />
            <ProductCard />
            <ProductCard />
            <ProductCard />
          </div>
        </section>

        {/* 이벤트 */}
        <section className="home-section">
          <SectionHeader title="진행중인 이벤트" description="놓치지 마세요" />
          <div className="event-banner">
            <img
              src="https://image.ssfshop.com/upload/event/banner-01.jpg"
              alt="이벤트 배너"
            />
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
