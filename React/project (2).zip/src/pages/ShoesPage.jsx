import React from "react";
import "./ShoesPage.css";

function ShoesPage() {
  return (
    <div className="page">
      <h1>백&슈즈 페이지</h1>
    </div>
  );
}

export default ShoesPage;
