export default function PolicyPage() {
  return (
    <div className="container mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold">정책</h1>
      <p className="mt-4">개인정보처리방침과 이용약관 페이지입니다.</p>
    </div>
  );
}
