import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

export default function LoginPage({ history }) {
  const { login } = useContext(AuthContext);

  const handleLogin = () => {
    login();
    history.push("/"); // 로그인 후 홈으로 이동
  };

  return (
    <div className="container mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold mb-4">로그인</h1>
      <button
        onClick={handleLogin}
        className="px-4 py-2 bg-black text-white rounded"
      >
        로그인하기
      </button>
    </div>
  );
}
