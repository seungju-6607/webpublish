import React from "react";
import "./BeautyPage.css";

function BeautyPage() {
  return (
    <div className="page">
      <h1>뷰티 페이지</h1>
    </div>
  );
}

export default BeautyPage;
