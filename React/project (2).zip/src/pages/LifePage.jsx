import React from "react";
import "./LifePage.css";

function LifePage() {
  return (
    <div className="page">
      <h1>라이프 페이지</h1>
    </div>
  );
}

export default LifePage;
