import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Header.css";

function Header() {
  const [activeMenu, setActiveMenu] = useState(null);

  const handleMouseEnter = (menu) => setActiveMenu(menu);
  const handleMouseLeave = () => setActiveMenu(null);

  return (
    <header className="header">
      {/* 로고 + 아이콘 */}
      <div className="header-top">
        <h1 className="logo">
          <Link to="/">SSF 10th</Link>
        </h1>
        <div className="header-icons">
          <span className="icon">🔍</span>
          <span className="icon">♡</span>
          <span className="icon">🛒</span>
        </div>
      </div>

      {/* 네비게이션 - 딱 하나만 */}
      <nav className="header-nav">
        <ul>
          <li onMouseEnter={() => handleMouseEnter("women")} onMouseLeave={handleMouseLeave}>
            <Link to="/women">여성</Link>
            {activeMenu === "women" && (
              <div className="dropdown">
                <div className="dropdown-col">
                  <p>메인</p><p>신상품</p><p>전체 상품</p>
                  <p>아우터</p><p>재킷/베스트</p>
                </div>
                <div className="dropdown-col">
                  <p>스커트</p><p>라운지/언더웨어</p><p>비치웨어</p>
                </div>
                <div className="dropdown-col">
                  <h4>Top Brand</h4>
                  <p>에잇세컨즈</p><p>빈폴</p><p>구호</p>
                </div>
              </div>
            )}
          </li>

          <li><Link to="/men">남성</Link></li>
          <li><Link to="/kids">키즈</Link></li>
          <li><Link to="/luxury">럭셔리</Link></li>
          <li><Link to="/shoes">백&슈즈</Link></li>
          <li><Link to="/sports">스포츠</Link></li>
          <li><Link to="/golf">골프</Link></li>
          <li><Link to="/beauty">뷰티</Link></li>
          <li><Link to="/life">라이프</Link></li>
          <li><Link to="/outlet">아울렛</Link></li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;
