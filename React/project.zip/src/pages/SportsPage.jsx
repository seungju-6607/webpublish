import React from "react";
import "./SportsPage.css";

function SportsPage() {
  return (
    <div className="page">
      <h1>스포츠 페이지</h1>
    </div>
  );
}

export default SportsPage;
