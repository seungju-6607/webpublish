export default function MenPage() {
  return (
    <div className="container mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold">Men</h1>
      <p className="mt-4">남성 카테고리 상품 페이지입니다.</p>
    </div>
  );
}
