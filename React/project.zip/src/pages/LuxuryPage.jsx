import React from "react";
import "./LuxuryPage.css";

function LuxuryPage() {
  return (
    <div className="page">
      <h1>럭셔리 페이지</h1>
    </div>
  );
}

export default LuxuryPage;
