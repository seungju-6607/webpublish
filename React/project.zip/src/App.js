import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Header from "./components/Header";
import Home from "./pages/Home";
import WomenPage from "./pages/WomenPage";
import MenPage from "./pages/MenPage";
import KidsPage from "./pages/KidsPage";
import LuxuryPage from "./pages/LuxuryPage";
import ShoesPage from "./pages/ShoesPage";
import SportsPage from "./pages/SportsPage";
import GolfPage from "./pages/GolfPage";
import BeautyPage from "./pages/BeautyPage";
import LifePage from "./pages/LifePage";
import OutletPage from "./pages/OutletPage";

function App() {
  return (
    <Router>
      <Header />
      <Switch>
        <Route exact path="/" component={Home} />
        <Route path="/women" component={WomenPage} />
        <Route path="/men" component={MenPage} />
        <Route path="/kids" component={KidsPage} />
        <Route path="/luxury" component={LuxuryPage} />
        <Route path="/shoes" component={ShoesPage} />
        <Route path="/sports" component={SportsPage} />
        <Route path="/golf" component={GolfPage} />
        <Route path="/beauty" component={BeautyPage} />
        <Route path="/life" component={LifePage} />
        <Route path="/outlet" component={OutletPage} />
      </Switch>
    </Router>
  );
}

export default App;
